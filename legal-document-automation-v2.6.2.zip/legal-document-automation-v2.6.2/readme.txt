=== Use-your-Drive ===
Requires at least: 5.8 
Tested up to: 6.8.2
Requires PHP: 7.4

Say hello to the most popular WordPress Google Drive plugin! Use-your-Drive is a user-friendly, highly customizable, innovative Google Drive integration plugin for WordPress that displays your Google Drive files in a beautiful way. No coding skills required!

== Description ==

Say hello to the most popular WordPress Google Drive plugin! Use-your-Drive is a user-friendly, highly customizable, innovative Google Drive integration plugin for WordPress that displays your Google Drive files in a beautiful way. No coding skills required!

This plugin will help you to easily integrate Google Drive into your WordPress website or blog. Use-your-Drive allows you to view, download, delete, rename files & folders stored in the cloud directly from a WordPress page. You can use Use-your-Drive as a File browser, Upload Box, Gallery, Audio- or Video-Player!

== Changelog ==
You can find the Changelog in the [Documentation](https://www.wpcloudplugins.com/wp-content/plugins/use-your-drive/_documentation/index.html#releasenotes).

== Upgrade Notice ==

If you have multiple WP Cloud Plugins on your site, please make sure they are all updated to avoid compatibility issues.

= 3.3.2 = 
This version fixes a security-related bug.